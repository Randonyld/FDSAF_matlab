clc; clear; close all;
load saf.mat
load fdsaf.mat

figure; grid on; hold on; box on;
set(gca, 'FontSize', 16, 'fontname', 'Times New Roman');
f1 = plot(emf_saf, '--', 'linewidth', 2);
f2 = plot(emf_fdsaf, ':', 'linewidth', 2);
nummarkers([f1, f2], 8);
plot(-30*ones(size(emf_saf)), 'k--', 'linewidth', 3);
xlabel('Samples');
ylabel('MSE [dB]'); ylim([-32, 0]);
title('Comparison of MSE Curves $(M=120)$', 'interpreter', 'latex');
legend(['SAF       Time = ', num2str(1000*time_saf), ' ms'], ['FDSAF  Time = ', num2str(1000*time_fdsaf), ' ms']);
set(gca, 'XTicklabel', [0, 20000, 40000, 60000, 80000, 100000]);

kappa = time_fdsaf/time_saf