%% Subfunc
function [u, y] = interp_local(Qi, n)
u = (linspace(0, 1, n))';
y = zeros(size(u));
for i = 1:length(u)
    U = [u(i)^3, u(i)^2, u(i), 1]'; % vector U
    C = 1/2*[-1,  3, -3,  1; ...
              2, -5,  4, -1; ...
             -1,  0,  1,  0; ...
              0,  2,  0,  0];
    y(i) = U'*C*Qi; % spline output
end
end