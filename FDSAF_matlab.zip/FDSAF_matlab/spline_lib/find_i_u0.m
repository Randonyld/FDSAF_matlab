%% Subfunc
function [ind, u] = find_i_u0(qx, dx, qn_m, sn)
% qn is an odd number, index of the middle point is (qn+1)/2
% ind from 2 to lenth(qx)-2
if sn < qx(2)
    ind = 2;
    u = 0;
elseif sn >= qx(end-1)
    ind = length(qx) - 2;
    u = 1;
else
    fl = floor(sn/dx);
    ind = fl + qn_m;
    u = sn/dx - fl;
end
end