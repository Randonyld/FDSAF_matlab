function [s_i, param] = spline_inverse(qx, qy, search_ind, y_i, eps, flag)
% search the corresponding interval
ind_yi = find_inv_i(qy, y_i, search_ind);
if ind_yi == 2
    s_i = qx(2);
    param = [];
    return;
elseif ind_yi == length(qy) - 1
    s_i = qx(end-1);
    param = [];
    return;
end
% local knots vector
Q_l = qy(ind_yi-1:ind_yi+2) - y_i;
% intersection between line segment of two nodes and yc
if Q_l(3) == Q_l(2)
    u_i = 0.5;
else
    u_i = Q_l(2)/(Q_l(2)-Q_l(3));
end
% Newton iteration method
C = 1/2*[-1,  3, -3,  1; ...
          2, -5,  4, -1; ...
         -1,  0,  1,  0; ...
          0,  2,  0,  0];
err = 1;
count = 0;

if flag == 1 % plot the local spline curve
    figure(11); hold on; grid on; box on;
    set(gca, 'FontSize', 18, 'Fontname', 'Times New Roman');
    [xx_l, yy_l] = interp_local(Q_l, 5000);
    plot(xx_l, yy_l, '-', 'linewidth', 2); % local spline curve
    plot([0; 1], Q_l(2:3), '--*', 'linewidth', 2); % segment line
    plot(xx_l, zeros(size(xx_l)), 'k--'); % zeros line
end
while abs(err) > eps && count < 12
    U = [u_i^3, u_i^2, u_i, 1]';
    dU = [3*u_i^2, 2*u_i, 1, 0]';
    fu_i = U'*C*Q_l;
    dfu_i = dU'*C*Q_l;
    
    if flag == 1
        plot([u_i, u_i], [0, fu_i], '-o', 'linewidth', 2); % vertical segment line
        xx_t = xx_l;
        yy_t = (xx_t - u_i)*dfu_i + fu_i;
        plot(xx_t, yy_t, '--', 'linewidth', 1); % tangent line
    end
    
    u_i = u_i - fu_i/dfu_i;
    
    if u_i > 1 || u_i < 0
        u_i = rand;
        count = count + 1;
        continue;
    end
    
    err = fu_i - 0;
    count = count + 1;
    
    if flag == 1
        plot(u_i, 0, 'x'); % new root
    end
end
% u2s
s_i = qx(ind_yi) + u_i*(qx(ind_yi+1)-qx(ind_yi));

% plot the whole spline curve
if flag == 1
    figure(12); hold on; grid on; box on;
    set(gca, 'FontSize', 18, 'Fontname', 'Times New Roman');
    [xx_g, yy_g] = interp_global(qx, qy, search_ind, 1000);
    plot(qx, qy, '.', 'markersize', 20);
    plot(xx_g, yy_g, '-', 'linewidth', 2);
    plot(xx_g, y_i*ones(size(xx_g)), 'k--', 'linewidth', 1);
    plot(s_i, y_i, 'b+', 'linewidth', 2, 'markersize', 10);
end

% output other parameters
param.count = count;
param.err = err;
end