%% Subfunc
function [x, y] = interp_global(qx, qy, search_ind, n)
x = (linspace(qx(1), qx(end), n))';
y = zeros(size(x));
for i = 1:length(x)
    [ind, u] = find_i_u(qx, x(i), search_ind); % find ind and u
    U = [u^3, u^2, u, 1]'; % vector U
    Qi = qy(ind-1:ind+2); % vector q
    C = 1/2*[-1,  3, -3,  1; ...
              2, -5,  4, -1; ...
             -1,  0,  1,  0; ...
              0,  2,  0,  0];
    y(i) = U'*C*Qi; % spline output
end
end