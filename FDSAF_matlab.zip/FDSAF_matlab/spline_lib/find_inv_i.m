%% Subfunc
function ind_yc = find_inv_i(qy, y_i, search_ind)
% qn is an odd number, index of the middle point is (qn+1)/2
% ind from 2 to lenth(qx)-1
[min_, min_ind] = min(qy);
[max_, max_ind] = max(qy);

if y_i <= min_
    ind_yc = min_ind + 1;
    return;
elseif y_i >= max_
    ind_yc = max_ind - 1;
    return;
end
if y_i < qy(2)
    ind_yc = 2;
    return;
elseif y_i > qy(end-2)
    ind_yc = length(qy)-2;
    return;
end  
for i = 1:length(search_ind)
    s_ind = search_ind(i);
    if (y_i - qy(s_ind))*(y_i - qy(s_ind+1)) <= 0
        ind_yc = s_ind;
        break;
    end
end
end