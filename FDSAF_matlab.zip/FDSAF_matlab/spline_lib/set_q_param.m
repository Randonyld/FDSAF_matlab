function [qx, qy, qn, qn_m, dx, C] = set_q_param(qx1, qx2, qn)
% Parameters setting
C = 1/2*[-1,  3, -3,  1; ...
          2, -5,  4, -1; ...
         -1,  0,  1,  0; ...
          0,  2,  0,  0];

qx = linspace(qx1, qx2, qn)';
dx = qx(2) - qx(1);
qy = qx; % initialize spline filter weights
% Extend q
qx = [qx(1) - dx; qx; qx(end) + dx];
qy = [qy(1); qy; qy(end)];

qn = length(qx);
qn_m = (qn+1)/2;
end