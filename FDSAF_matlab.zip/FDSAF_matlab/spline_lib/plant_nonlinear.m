function y = plant_nonlinear(s)


end