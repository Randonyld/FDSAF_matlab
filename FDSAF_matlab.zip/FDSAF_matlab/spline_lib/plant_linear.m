function [num, den] = plant_linear(arg)
% plant model
if arg == 1
    num = conv([0, 2.4], [1, -0.8]);
    den = conv([1, 0.6], [1, -0.7]);
elseif arg == 2
    s = tf('s');
    G = 24*(s-0.5)/((s+1)^2*(s+2));
    Gd = c2d(G, 0.1, 'zoh');
    [num, den] = tfdata(Gd, 'v');
% reference model
elseif arg == 5
    num = [0, 0.25, 0];
    den = [1, -1, 0.25];
elseif arg == 6
    s = tf('s');
    M = 5.0119*(s+5)/(s^2+10.0118*s+25.0594);
    Md = c2d(M, 0.02, 'zoh');
    [num, den] = tfdata(Md, 'v');
% error
else
    error('Error: Invalid input arguments!');
end
end