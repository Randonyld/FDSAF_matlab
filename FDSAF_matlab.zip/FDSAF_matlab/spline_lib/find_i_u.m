%% Subfunc
function [ind, u] = find_i_u(qx, sn, search_ind)
% qn is an odd number, index of the middle point is (qn+1)/2
% ind from 2 to lenth(qx)-2
% if sn < qx(2)
%     ind = 2;
%     u = 0;
%     return;
% elseif sn >= qx(end-1)
%     ind = length(qx) - 2;
%     u = 1;
%     return;
% end

% for i = 1:length(search_ind)
%     s_ind = search_ind(i);
%     if sn >= qx(s_ind) && sn < qx(s_ind+1)
%         ind = s_ind;
%         u = (sn - qx(ind))/(qx(ind+1)-qx(ind));
%         break;
%     end
% end

dx = qx(2) - qx(1);
nq = length(qx) - 1;
fl = floor(sn/dx);
ind = fl + nq/2 + 1;
u = sn/dx - fl;
if sn < qx(2)
    ind = 2;
    u = 0;
    return;
elseif sn >= qx(end-1)
    ind = length(qx) - 2;
    u = 1;
    return;
end
end