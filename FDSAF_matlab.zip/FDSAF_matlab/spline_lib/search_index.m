%% Subfunc
function search_ind = search_index(qx)
% arrange search intervals from middle to both sides
% the output range is [2, length(qx)-2]
qn = length(qx);
m_qn = (qn+1)/2;
search_ind_l = m_qn-1:-1:2;
search_ind_r = m_qn:1:qn-2;
search_ind = [];
for i = 1:m_qn-2
    search_ind = [search_ind, search_ind_l(i), search_ind_r(i)];
end
end