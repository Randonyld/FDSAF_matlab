clc; clear; close all;
%%
figure; hold on; grid on; box on;
set(gca, 'fontname', 'Times New Roman', 'fontsize', 16);
M = 1:1000;
plot((5*log2(M)+31)./(M+34), 'linewidth', 2);
xlabel('FIR filter length $M$', 'interpreter', 'latex');ylabel('Complexity ratio $\kappa(M)$', 'interpreter', 'latex');
title('Complexity ratio of FDSAF and SAF');
%%
axes('position', [0.35, 0.45, 0.5, 0.4]);
set(gca, 'fontname', 'Times New Roman', 'fontsize', 16);
ind = 1:120;
hold on; grid on; box on;
plot((5*log2(ind)+31)./(ind+34), 'linewidth', 2);
xlim([0, 120]);
set(gca,'XTick', [0, 20, 40, 60, 80, 100, 120]);
set(gca, 'XTicklabel', [0, 20, 40, 60, 80, 100, 120]);