clc; clear; close all;
%% Setting Parameters
N = 1e5; % modeling stage
% FIR of P
num7 = [-2.816e10, 4.573e16, 6.441e19, 3.184e25];
den7 = [1, 1.024e4, 2.586e9, 1.224e13, 1.247e18, 2.132e21, 9.45e23, 9.722e26];
G7 = tf(num7, den7);
Td = 6e-5;
Gz7 = c2d(G7, Td, 'zoh');
[num_p, den_p] = tfdata(Gz7, 'v');
M_p = 1000;
w_p = 100*dimpulse(num_p, den_p, M_p);
% q of P
qx_p = (-2.2:0.2:2.2)';
% qy_p = [-2.2:0.2:-0.8, -0.91, -0.42, -0.01, -0.10, 0.1, -0.15, 0.58, 1.2, 1.0:0.2:2.2]';
qy_p = atan(2*qx_p);
search_ind = search_index(qx_p);

ntrial = 50; % number of trials
em = zeros(N, 1); % MSE
time_consume = 0;
for kk = 1:ntrial
kk
% x = 2*(rand(N, 1)-0.5); % input signal
% x = 2*sin((1:N)/256)' + 0.05*2*(rand(N, 1)-0.5);
% x = 0.1*x;
x = randn(N, 1);

snr = 30; % signal-to-noise ratio
noise = 10^(-snr/20)*randn(size(x)); % noise

% identified FIR
M_m = M_p;
w_m = zeros(M_m, 1); w_m(1) = 1;
% identified q
[qx_m, qy_m, qn, qn_m, dx, C] = set_q_param(-2, 2, 21);
%% Identification
s_p = zeros(N, 1); % plant
y_p = zeros(N, 1); % plant

y_m = zeros(N, 1); % model
e_m = zeros(N, 1); % modeling error
for n = M_p:N
    % plant
    s_p(n) = w_p'*x(n:-1:n-M_p+1);
    [ind0, u0] = find_i_u0(qx_p, dx, qn_m, s_p(n));
    U0 = [u0^3, u0^2, u0, 1]';
    y_p(n) = U0'*C*qy_p(ind0-1:ind0+2) + noise(n);
end

O = zeros(M_m, 1);
X_f = zeros(M_m, M_m);

s_tmp = zeros(2*M_m, 1);
s_b = zeros(M_m, 1);

ind_b = zeros(1, M_m);
u_b = zeros(1, M_m);
U_b = ones(4, M_m);
dU_b = zeros(4, M_m); dU_b(3, :) = 1;
Q_b = zeros(4, M_m);
% learning rate
lr_w = 0.0001;

k_len = fix(N/M_m)-1;


dw = zeros(M_m, 1);
% tic;
time_consume_M = 0;
for k = 2:k_len
    tic;
    n_ind0 = (k-1)*M_m+1:k*M_m;
    n_ind1 = k*M_m+1:(k+1)*M_m;
    for i = 1:M_m
        indx = k*M_m+1 + i-1 : -1 : k*M_m+1-M_m+1 + i-1;
        X_f = x(indx);
        y_m(i) = w_m'*X_f;
        e_m(k*M_m+1+i-1) = y_p(k*M_m+1+i-1) - y_m(k*M_m+1+i-1);
        
        dw = dw + e_m(k*M_m+1+i-1)*X_f;
    end
    w_m = w_m + lr_w*dw;
    dw = zeros(M_m, 1);
    
    time_consume_M = time_consume_M + toc;
end
time_consume = time_consume + time_consume_M/k_len;
em = em + e_m.^2;
end
time_consume = time_consume/ntrial
%% Learning Curve
em = em/ntrial;
em(1:2*M_p) = 1;
edb = 10*log10(em);
emf = zeros(size(edb));
lambda = 0.95;
for n = 2:length(emf)
    emf(n) = lambda*emf(n-1) + (1-lambda)*edb(n);
end
noiseLevel(1: length(emf)) = -snr;

figure; hold on; grid on; box on;
set(gca, 'FontSize', 15, 'FontWeight', 'bold');
plot(emf, 'Color', [1 0 0], 'LineWidth', 2); plot(noiseLevel, '--', 'Color', [0 0 1], 'LineWidth', 2);
title('\bfSystem identification test'); xlabel('Samples'); ylabel('MSE/dB'); legend('MSE', 'NoiseLevel');

emf_blocklms = emf;
time_blocklms = time_consume;
save blocklms.mat emf_blocklms time_blocklms


% modeling result
Col = linspecer(3);
figure; hold on; grid on; box on;
set(gca, 'FontSize', 16, 'fontname', 'Times New Roman');
plot(y_p, '--', 'color', Col(1, :)); plot(y_m, '-.', 'color', Col(3, :)); plot(e_m, 'color', Col(2, :));
xlabel('Samples'); title('System Identification Result');
legend('desired output $d(n)$', 'model output $y(n)$', 'filter error $e(n)$', 'location', 'northeast', 'interpreter', 'latex');
set(gca, 'XTicklabel', [0, 20000, 40000, 60000, 80000, 10000]);


figure; hold on; grid on; box on;
set(gca, 'FontSize', 16, 'fontname', 'Times New Roman');
plot(w_p, 'b--', 'linewidth', 3); plot(w_m, 'r-.', 'linewidth', 2);
ylabel('$\mathbf{w}$', 'interpreter', 'latex'); 
title('FIR Filter Weight');
l1 = legend('Desired weight $\mathbf{w}^*$', 'Filtered weight $\mathbf{w}(n)$', 'location', 'best', 'interpreter', 'latex');
set(l1, 'fontsize', 16, 'location', 'northeast', 'box', 'on');