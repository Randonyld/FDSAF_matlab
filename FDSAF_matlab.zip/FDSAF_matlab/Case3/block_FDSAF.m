clc; clear; close all;
%% Setting Parameters
N = 1e5; % modeling stage
% FIR of P
num7 = [-2.816e10, 4.573e16, 6.441e19, 3.184e25];
den7 = [1, 1.024e4, 2.586e9, 1.224e13, 1.247e18, 2.132e21, 9.45e23, 9.722e26];
G7 = tf(num7, den7);
Td = 6e-5;
Gz7 = c2d(G7, Td, 'zoh');
[num_p, den_p] = tfdata(Gz7, 'v');
M_p = 1000;
w_p = 100*dimpulse(num_p, den_p, M_p);
% q of P
qx_p = (-2.2:0.2:2.2)';
% qx_p = (-4.4:0.4:4.4)';
% qy_p = [-2.2:0.2:-0.8, -0.91, -0.42, -0.01, -0.10, 0.1, -0.15, 0.58, 1.2, 1.0:0.2:2.2]';
qy_p = atan(2*qx_p);
search_ind = search_index(qx_p);

ntrial = 50; % number of trials
em = zeros(N, 1); % MSE
time_consume = 0;
for kk = 1:ntrial
% x = 2*(rand(N, 1)-0.5); % input signal
% x = 2*sin((1:N)/256)' + 0.05*2*(rand(N, 1)-0.5);
% x = 0.1*x;
x = randn(N, 1);

snr = 30; % signal-to-noise ratio
noise = 10^(-snr/20)*randn(size(x)); % noise

% identified FIR
M_m = M_p;
w_m = zeros(M_m, 1); w_m(1) = 1;
% identified q
[qx_m, qy_m, qn, qn_m, dx, C] = set_q_param(-2, 2, 21);
%% Identification
s_p = zeros(N, 1); % plant
y_p = zeros(N, 1); % plant

y_m = zeros(N, 1); % model
e_m = zeros(N, 1); % modeling error
for n = M_p:N
    % plant
    s_p(n) = w_p'*x(n:-1:n-M_p+1);
    [ind0, u0] = find_i_u0(qx_p, dx, qn_m, s_p(n));
    U0 = [u0^3, u0^2, u0, 1]';
    y_p(n) = U0'*C*qy_p(ind0-1:ind0+2) + noise(n);
end

O = zeros(M_m, 1);
X_f = zeros(2*M_m, 1);
W_f = fft([w_m; zeros(M_m, 1)]);

s_tmp = zeros(2*M_m, 1);
s_b = zeros(M_m, 1);

ind_b = zeros(1, M_m);
u_b = zeros(1, M_m);
U_b = ones(4, M_m);
dU_b = zeros(4, M_m); dU_b(3, :) = 1;
Q_b = zeros(4, M_m);
% learning rate
lr_w = 0.0001;
lr_q = 0.005;

k_len = fix(N/M_m)-1;

% tic;
time_consume_M = 0;
for k = 1:k_len
    tic;
    n_ind = (k-1)*M_m+1:(k+1)*M_m;
    n_ind1 = k*M_m+1:(k+1)*M_m;
    X_f = fft(x(n_ind));
    s_tmp = real(ifft(X_f.*W_f));
    s_b = s_tmp(end/2+1:end);
    for i = 1:M_m
        if s_b(i) < qx_m(2)
            ind_b(i) = 2;
            u_b(i) = 0;
        elseif s_b(i) >= qx_m(end-1)
            ind_b(i) = qn - 2;
            u_b(i) = 1;
        else
            ind_ = s_b(i)/dx;
            fl = floor(ind_);
            ind_b(i) = fl + qn_m;
            u_b(i) = ind_ - fl;
        end
        Q_b(:, i) = qy_m(ind_b(i)-1:ind_b(i)+2);
    end
    U_b(1, :) = u_b.^3;
    U_b(2, :) = u_b.^2;
    U_b(3, :) = u_b;
    dU_b(1, :) = 3*U_b(2, :);
    dU_b(2, :) = 2*u_b;
    
    CQ = C*Q_b;
    y_m(n_ind1) = sum(CQ.*U_b, 1)';
    e_m(n_ind1) = y_p(n_ind1) - y_m(n_ind1);
    ew = sum(CQ.*dU_b, 1)'.*e_m(n_ind1)/dx;
    
    DQ = lr_q*C'*U_b.*e_m(n_ind1)';
    for i = search_ind
        ind_i = find(ind_b - i == 0);
        DQi = DQ(:, ind_i);
        qy_m(i-1:i+2) = qy_m(i-1:i+2) + sum(DQi, 2);
    end
    
    E_f = fft([O; ew]);
    dw = real(ifft(conj(X_f).*E_f));
    W_f = W_f + lr_w*fft([dw(1:M_m); O]);
    
    time_consume_M = time_consume_M + toc;
end
time_consume = time_consume + time_consume_M/k_len;
em = em + e_m.^2;
end
time_consume = time_consume/ntrial
%% Learning Curve
em = em/ntrial;
em(1:M_p) = 1;
edb = 10*log10(em);
emf = zeros(size(edb));
lambda = 0.95;
for n = 2:length(emf)
    emf(n) = lambda*emf(n-1) + (1-lambda)*edb(n);
end
noiseLevel(1: length(emf)) = -snr;

figure; hold on; grid on; box on;
set(gca, 'FontSize', 15, 'FontWeight', 'bold');
plot(emf, 'Color', [1 0 0], 'LineWidth', 2); plot(noiseLevel, '--', 'Color', [0 0 1], 'LineWidth', 2);
title('\bfSystem identification test'); xlabel('Samples'); ylabel('MSE/dB'); legend('MSE', 'NoiseLevel');

emf_fdsaf = emf;
time_fdsaf = time_consume;
save fdsaf.mat emf_fdsaf time_fdsaf


% modeling result
Col = linspecer(3);
figure; hold on; grid on; box on;
set(gca, 'FontSize', 16, 'fontname', 'Times New Roman');
plot(y_p, '--', 'color', Col(1, :)); plot(y_m, '-.', 'color', Col(3, :)); plot(e_m, 'color', Col(2, :));
xlabel('Samples'); title('System Identification Result');
legend('desired output $d(n)$', 'model output $y(n)$', 'filter error $e(n)$', 'location', 'northeast', 'interpreter', 'latex');
set(gca, 'XTicklabel', [0, 20000, 40000, 60000, 80000, 10000]);


w_m = real(ifft(W_f));
w_m = w_m(1:M_m);
figure; hold on; grid on; box on;
set(gca, 'FontSize', 16, 'fontname', 'Times New Roman');
plot(w_p, 'b--', 'linewidth', 3); plot(w_m, 'r-.', 'linewidth', 2);
ylabel('$\mathbf{w}$', 'interpreter', 'latex'); 
title('FIR Filter Weight');
l1 = legend('Desired weight $\mathbf{w}^*$', 'Filtered weight $\mathbf{w}(n)$', 'location', 'best', 'interpreter', 'latex');
set(l1, 'fontsize', 16, 'location', 'northeast', 'box', 'on');

[xxp, yyp] = interp_global(qx_p, qy_p, search_ind, 200);
[xxm, yym] = interp_global(qx_m, qy_m, search_ind, 200);
figure; hold on; grid on; box on; xlim([qx_m(2), qx_m(end-1)]); ylim([qy_m(2), qy_m(end-1)]);
set(gca, 'FontSize', 16, 'fontname', 'Times New Roman');
plot(xxp, yyp, 'b--', 'linewidth', 3); plot(xxm, yym, 'r-.', 'linewidth', 2); plot(qx_m, qx_m, 'k--', 'linewidth', 1);
xlabel('Nonlinear input $s$', 'interpreter', 'latex');
ylabel('Nonlinear output $y$', 'interpreter', 'latex');
title('Spline Curve');
l2 = legend('Desired knots $\mathbf{q}^*$', 'Filtered knots $\mathbf{q}(n)$', ' initialization', 'location', 'southeast', 'interpreter', 'latex');
set(l2, 'fontsize', 16, 'location', 'southeast', 'box', 'on');