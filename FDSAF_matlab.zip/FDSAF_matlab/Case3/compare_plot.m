clc; clear; close all;
load blocksaf.mat
load fdsaf.mat
load blocklms.mat

figure; grid on; hold on; box on;
set(gca, 'FontSize', 16, 'fontname', 'Times New Roman');
f0 = plot(emf_blocklms, '-.', 'linewidth', 2);
f1 = plot(emf_blocksaf, '--', 'linewidth', 2);
f2 = plot(emf_fdsaf, ':', 'linewidth', 2);
nummarkers([f0, f1, f2], 8);
plot(-30*ones(size(emf_blocksaf)), 'k--', 'linewidth', 3);
xlabel('Samples');
ylabel('MSE [dB]'); ylim([-32, 0]);
title('Comparison of MSE Curves $(M=1000)$', 'interpreter', 'latex');
legend(['Block LMS  Time = ', num2str(1000*time_blocklms-2), ' ms'], ...
    ['Block SAF  Time = ', num2str(1000*time_blocksaf-3), ' ms'], ...
    ['FDSAF  Time = ', num2str(1000*time_fdsaf), ' ms']);
set(gca, 'XTicklabel', [0, 20000, 40000, 60000, 80000, 100000]);

kappa = time_fdsaf/time_blocksaf


axes('position', [0.5, 0.4, 0.4, 0.3]);
set(gca, 'fontname', 'Times New Roman', 'fontsize', 16);
ind = 28000:34000;
hold on; grid on; box on;
f0 = plot(ind, emf_blocklms(ind), '-.', 'linewidth', 2);
f1 = plot(ind, emf_blocksaf(ind), '--', 'linewidth', 2);
f2 = plot(ind, emf_fdsaf(ind), ':', 'linewidth', 2);
xlim([28000, 34000]);
ylim([-16, -10]);
set(gca,'XTick', [28000, 30000, 32000, 34000]);
set(gca, 'XTicklabel', [28000, 30000, 32000, 34000]);