clc; clear; close all;
load saf.mat
load fdsaf.mat

figure; grid on; hold on; box on;
set(gca, 'FontSize', 16, 'fontname', 'Times New Roman');
f1 = plot(emf_saf, '--', 'linewidth', 2);
f2 = plot(emf_fdsaf, ':', 'linewidth', 2);
nummarkers([f1, f2], 8);
plot(-30*ones(size(emf_saf)), 'k--', 'linewidth', 3);
xlabel('Samples');
ylabel('MSE [dB]'); ylim([-32, 0]);
title('Comparison of MSE Curves $(M=1000)$', 'interpreter', 'latex');
legend(['SAF       Time = ', num2str(1000*time_saf), ' ms'], ['FDSAF  Time = ', num2str(1000*time_fdsaf), ' ms']);
% legend(['SAF       Time = 9.9583 ms'], ['FDSAF  Time = 1.0801 ms']);
set(gca, 'XTicklabel', [0, 20000, 40000, 60000, 80000, 100000]);

kappa = time_fdsaf/time_saf


axes('position', [0.42, 0.45, 0.45, 0.3]);
set(gca, 'fontname', 'Times New Roman', 'fontsize', 16);
ind = 16000:22000;
hold on; grid on; box on;
f1 = plot(ind, emf_saf(ind), '--', 'linewidth', 2);
f2 = plot(ind, emf_fdsaf(ind), ':', 'linewidth', 2);
xlim([16000, 22000]);
ylim([-20, -10]);
set(gca,'XTick', [16000, 18000, 20000, 22000]);
set(gca, 'XTicklabel', [16000, 18000, 20000, 22000]);