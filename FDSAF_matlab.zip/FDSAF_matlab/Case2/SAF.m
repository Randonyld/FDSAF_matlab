clc; clear; close all;
%% Setting Parameters
N = 1e5; % modeling stage
% FIR of P
num7 = [-2.816e10, 4.573e16, 6.441e19, 3.184e25];
den7 = [1, 1.024e4, 2.586e9, 1.224e13, 1.247e18, 2.132e21, 9.45e23, 9.722e26];
G7 = tf(num7, den7);
Td = 6e-5;
Gz7 = c2d(G7, Td, 'zoh');
[num_p, den_p] = tfdata(Gz7, 'v');
M_p = 1000;
w_p = 100*dimpulse(num_p, den_p, M_p);
% q of P
qx_p = (-2.2:0.2:2.2)';
% qy_p = [-2.2:0.2:-0.8, -0.91, -0.42, -0.01, -0.10, 0.1, -0.15, 0.58, 1.2, 1.0:0.2:2.2]';
qy_p = atan(2*qx_p);
search_ind = search_index(qx_p);

ntrial = 200; % number of trials
em = zeros(N, 1); % MSE
time_consume = 0;
for kk = 1:ntrial
x = 2*(rand(N, 1)-0.5); % input signal
% x = 2*sin((1:N)/256)' + 0.05*2*(rand(N, 1)-0.5);
% x = 0.1*x;

snr = 30; % signal-to-noise ratio
noise = 10^(-snr/20)*randn(size(x)); % noise

% identified FIR
M_m = M_p;
w_m = zeros(M_m, 1); w_m(1) = 1;
% identified q
[qx_m, qy_m, qn, qn_m, dx, C] = set_q_param(-2, 2, 21);
%% Identification
s_p = zeros(N, 1); % plant
y_p = zeros(N, 1); % plant
s_m = zeros(N, 1);
y_m = zeros(N, 1);
e_m = zeros(N, 1);
% learning rate
lr_w = 0.0005;
lr_q = 0.01;

for n = M_p:N
    % plant
    s_p(n) = w_p'*x(n:-1:n-M_p+1);
    [ind0, u0] = find_i_u0(qx_p, dx, qn_m, s_p(n));
    U0 = [u0^3, u0^2, u0, 1]';
    Qi0 = qy_p(ind0-1:ind0+2);
    y_p(n) = U0'*C*Qi0 + noise(n);
end

k_len = fix(N/M_m)-1;
tic;
for n = 2*M_m:N
    % filtering
    Xn = x(n:-1:n-M_m+1); % input buffer
    s_m(n) = w_m'*Xn; % linear output
    if s_m(n) < qx_m(2)
        ind = 2;
        u = 0;
    elseif s_m(n) >= qx_m(end-1)
        ind = qn - 2;
        u = 1;
    else
        ind_ = s_m(n)/dx;
        fl = floor(ind_);
        ind = fl + qn_m;
        u = ind_ - fl;
    end
    Cq = C*qy_m(ind-1:ind+2);
    U = [u^3, u^2, u, 1]'; % vector U
    dU = [3*u^2, 2*u, 1, 0]'; % derivative of vector U
    y_m(n) = U'*Cq; % spline output
    % update
    e_m(n) = y_p(n) - y_m(n); % error
    
    qy_m(ind-1:ind+2) = qy_m(ind-1:ind+2) + lr_q*e_m(n)*C'*U; % update qy
    w_m = w_m + lr_w*e_m(n)/dx*dU'*Cq*Xn; % update w
end
time_consume = time_consume + toc;
em = em + e_m.^2;
end
time_consume = time_consume/k_len/ntrial
%% Learning Curve
em = em/ntrial;
em(1:2*M_p) = 1;
edb = 10*log10(em);
emf = zeros(size(edb));
lambda = 0.95;
for n = 2:length(emf)
    emf(n) = lambda*emf(n-1) + (1-lambda)*edb(n);
end
noiseLevel(1: length(emf)) = -snr;

figure; hold on; grid on; box on;
set(gca, 'FontSize', 15, 'FontWeight', 'bold');
plot(emf, 'Color', [1 0 0], 'LineWidth', 2); plot(noiseLevel, '--', 'Color', [0 0 1], 'LineWidth', 2);
title('\bfSystem identification test'); xlabel('Samples'); ylabel('MSE/dB'); legend('MSE', 'NoiseLevel');


emf_saf = emf;
time_saf = time_consume;
save saf.mat emf_saf time_saf


% modeling result
Col = linspecer(3);
figure; hold on; grid on; box on;
set(gca, 'FontSize', 16, 'FontWeight', 'bold');
Td = 0.1;
t = (0:N-1)*Td;
plot(y_p, '--', 'color', Col(1, :)); plot(y_m, '-.', 'color', Col(3, :)); plot(e_m, 'color', Col(2, :));
xlabel('Time/s'); title(['\bfSystem identification test']);
legend('plant output $y_p$', 'model output $y_m$', 'error $e_m$', 'location', 'northeast', 'interpreter', 'latex');


figure; hold on; grid on; box on;
set(gca, 'FontSize', 16, 'FontWeight', 'bold');
plot(w_p, 'b--', 'linewidth', 3); plot(w_m, 'r-.', 'linewidth', 2);
ylabel('\bfw'); title('\bfLinear Filter Weights');
l1 = legend('$\mathbf{w}^*$', '$\mathbf{w}_n$', 'location', 'best', 'interpreter', 'latex');
set(l1, 'fontsize', 16, 'location', 'northeast', 'box', 'on');

[xxp, yyp] = interp_global(qx_p, qy_p, search_ind, 200);
[xxm, yym] = interp_global(qx_m, qy_m, search_ind, 200);
figure; hold on; grid on; box on; xlim([qx_m(2), qx_m(end-1)]); ylim([qy_m(2), qy_m(end-1)]);
set(gca, 'FontSize', 16, 'FontWeight', 'bold');
plot(xxp, yyp, 'b--', 'linewidth', 3); plot(xxm, yym, 'r-.', 'linewidth', 2); plot(qx_m, qx_m, 'k--', 'linewidth', 1);
xlabel('Nonlinear input {\its}({\itn})'); ylabel('Nonlinear output {\ity}({\itn})'); title('\bfProfile of spline nonlinearity');
l2 = legend('$\mathbf{q}^*$', '$\mathbf{q}_n$', ' initialization', 'location', 'southeast', 'interpreter', 'latex');
set(l2, 'fontsize', 16, 'location', 'southeast', 'box', 'on');