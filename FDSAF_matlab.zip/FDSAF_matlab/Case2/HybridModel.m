clc; clear all; close all;
% 7th order model
num7 = [-2.816e10, 4.573e16, 6.441e19, 3.184e25];
den7 = [1, 1.024e4, 2.586e9, 1.224e13, 1.247e18, 2.132e21, 9.45e23, 9.722e26];
G7 = tf(num7, den7);
% 5th order model
num5 = [-2.816e10, 4.578e16];
den5 = [1, 8.424e3, 1.928e9, 3.313e12, 1.913e15, 1.57e18];
G5 = tf(num5, den5);
% 3th order model
num3 = [2.404e7];
den3 = [1, 2.556e3, 2.424e6, 8.235e8];
G3 = tf(num3, den3);
% discrete
Td = 5e-5;
Gz3 = c2d(G3, Td, 'zoh');
Gz5 = c2d(G5, Td, 'zoh');
Gz7 = c2d(G7, Td, 'zoh');
% step
figure;
subplot(311); impulse(G3, Gz3);
subplot(312); impulse(G5, Gz5);
subplot(313); impulse(G7, Gz7);
% bode
% figure; hold on;
% bode(G3); bode(G5); bode(G7);

% system response
N = 1e5;
u = randn(N, 1); % input
% u = sin(2*pi*0.01*(1:N)');
[numd3, dend3] = tfdata(Gz3, 'v');
Gz3 = tf(numd3, dend3, Td, 'Variable', 'z^-1')
y3 = dlsim(numd3, dend3, u);

[numd5, dend5] = tfdata(Gz5, 'v');
Gz5 = tf(numd5, dend5, Td, 'Variable', 'z^-1')
y5 = dlsim(numd5, dend5, u);

[numd7, dend7] = tfdata(Gz7, 'v');
Gz7 = tf(numd7, dend7, Td, 'Variable', 'z^-1')
y7 = dlsim(numd7, dend7, u);

figure; 
subplot(211); plot(u);
subplot(212); plot([y3, y5, y7]); legend('y3', 'y5', 'y7');

% correction model
x = y3;
y = zeros(size(x));
for i = 4:length(x)
    y(i) = atan(2*x(i)) + (0.1 - x(i-1))/(20 - 2*x(i-2)^2 + 5*x(i-3)^3);
end
snr = 30;
noise = 10^(-snr/20)*rms(y)*randn(size(y));
y = y + noise;
% save data.mat x y N
figure; plot([x, y]); legend('x', 'y');


M_p = 1000;
w_p = dimpulse(numd7, dend7, M_p);
figure; hold on; grid on; box on;
plot(w_p);