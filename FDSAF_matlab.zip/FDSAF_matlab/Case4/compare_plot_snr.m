clc; clear; close all;
load fdsaf5snr10.mat
load fdsaf5snr30.mat

% figure; grid on; hold on; box on;
% set(gca, 'FontSize', 16, 'fontname', 'Times New Roman');
% plot(-30*ones(size(emf_saf0)), 'k--', 'linewidth', 3);
% xlabel('Samples');
% ylabel('MSE [dB]'); ylim([-30, 0]); xlim([0, 100000]);
% title('Comparison of MSE Curves $(M=120)$', 'interpreter', 'latex');
% legend(['\alpha = 0,    SAF       ', num2str(1000*time_saf0), ' ms'], ['\alpha = 0,    FDSAF  ', num2str(1000*time_fdsaf0), ' ms'], ['\alpha = 0.5, SAF       ', num2str(1000*time_saf5), ' ms'], ['\alpha = 0.5, FDSAF  ', num2str(1000*time_fdsaf5), ' ms'], ['\alpha = 0.9, SAF       ', num2str(1000*time_saf9), ' ms'], ['\alpha = 0.9, FDSAF  ', num2str(1000*time_fdsaf9), ' ms'])
% set(gca, 'XTicklabel', [0, 20000, 40000, 60000, 80000, 100000]);


figure; hold on; grid on; box on;
set(gca, 'FontSize', 16, 'fontname', 'Times New Roman');
plot(w_p, 'b--', 'linewidth', 3);
plot(w_m30, 'r-', 'linewidth', 2);
plot(w_m10, '-.', 'linewidth', 2);
ylabel('$\mathbf{w}$', 'interpreter', 'latex'); 
title('FIR Filter Weight');
l1 = legend('Desired $\mathbf{w}^*$', 'Filtered $\mathbf{w}(n)$, 30 dB',...
    'Filtered $\mathbf{w}(n)$, 10 dB', 'location', 'best', 'interpreter', 'latex');
set(l1, 'fontsize', 16, 'location', 'northeast', 'box', 'on');

figure; hold on; grid on; box on; xlim([xxp(2), xxp(end-1)]); ylim([yyp(2), yyp(end-1)]);
set(gca, 'FontSize', 16, 'fontname', 'Times New Roman');
plot(xxp, yyp, 'b--', 'linewidth', 3); 
plot(xxm30, yym30, 'r-', 'linewidth', 2); 
plot(xxm10, yym10, '-.', 'linewidth', 2); 
xlabel('Nonlinear input $s$', 'interpreter', 'latex');
ylabel('Nonlinear output $y$', 'interpreter', 'latex');
title('Spline Curve');
l2 = legend('Desired $\mathbf{q}^*$', 'Filtered $\mathbf{q}(n)$, 30 dB',...
    'Filtered $\mathbf{q}(n)$, 10 dB', 'location', 'southeast', 'interpreter', 'latex');
set(l2, 'fontsize', 16, 'location', 'southeast', 'box', 'on');