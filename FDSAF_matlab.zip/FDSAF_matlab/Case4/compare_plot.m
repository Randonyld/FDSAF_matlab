clc; clear; close all;
load saf0.mat
load saf5.mat
load saf9.mat
load fdsaf0.mat
load fdsaf5.mat
load fdsaf9.mat

figure; grid on; hold on; box on;
set(gca, 'FontSize', 16, 'fontname', 'Times New Roman');
f1 = plot(emf_saf0, '-', 'linewidth', 1);
f2 = plot(emf_fdsaf0, '-.', 'linewidth', 1);
f3 = plot(emf_saf5, '--', 'linewidth', 2);
f4 = plot(emf_fdsaf5, ':', 'linewidth', 2);
f5 = plot(emf_saf9, '--', 'linewidth', 3);
f6 = plot(emf_fdsaf9, ':', 'linewidth', 3);
% nummarkers([f1, f2, f3, f4, f5, f6], 8);
plot(-30*ones(size(emf_saf0)), 'k--', 'linewidth', 3);
xlabel('Samples');
ylabel('MSE [dB]'); ylim([-30, 0]); xlim([0, 100000]);
title('Comparison of MSE Curves $(M=120)$', 'interpreter', 'latex');
legend(['\alpha = 0,    SAF       ', num2str(1000*time_saf0), ' ms'], ['\alpha = 0,    FDSAF  ', num2str(1000*time_fdsaf0), ' ms'], ['\alpha = 0.5, SAF       ', num2str(1000*time_saf5), ' ms'], ['\alpha = 0.5, FDSAF  ', num2str(1000*time_fdsaf5), ' ms'], ['\alpha = 0.9, SAF       ', num2str(1000*time_saf9), ' ms'], ['\alpha = 0.9, FDSAF  ', num2str(1000*time_fdsaf9), ' ms'])
set(gca, 'XTicklabel', [0, 20000, 40000, 60000, 80000, 100000]);

kappa0 = time_fdsaf0/time_saf0
kappa5 = time_fdsaf5/time_saf5
kappa9 = time_fdsaf9/time_saf9